package iut_bm_lp.projet_mountaincompanion_v1.views;

import android.location.Location;

/**
 * Created by light on 14/12/2017.
 */

public interface MountainCompanionActivity {

    void UpdateMarkers(Location location);
}
